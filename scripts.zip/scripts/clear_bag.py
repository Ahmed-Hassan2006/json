"""
clear_bag.py — Discard unwanted items from the bag

Reads clearbag.txt (one item name per line) and discards all matching items.
Uses Shift+Delete discard dialog with quantity 9999 (discard all).
"""

speak("Starting bag clear...")
clear_bag()
speak("Bag clear complete.")
