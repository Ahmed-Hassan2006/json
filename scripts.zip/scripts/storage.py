"""
Storage management script — retrieve potions and supplies from Ansible Space-Time Storehouse.

Configure what to take in config.ini under [storage]:

  [storage]
  storage_take = Large Red Potion:200|Large Blue Potion:200|Pet Large Red Potion:200|Pet Large Blue Potion:200

Each entry is "Item Name:Quantity" separated by |.
Quantity 0 or omitted = take all available (types 9999).

Run this script at the start of a farming session to restock from storage.
"""

# mwbot API is automatically injected into the global namespace

open_game_window()
sleep(1)

items_cfg = cfg_get("storage_take", "")

if not items_cfg.strip():
    speak("No items configured. Set storage_take in config.ini under [storage].")
else:
    for item_spec in items_cfg.split("|"):
        item_spec = item_spec.strip()
        if not item_spec:
            continue
        parts = item_spec.split(":")
        item_name = parts[0].strip()
        qty = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 0
        qty_label = str(qty) if qty > 0 else "all"
        speak(f"Taking {item_name} x{qty_label}")
        take_from_storage(item_name, qty)
        sleep(0.5)

speak("Storage retrieval complete.")
