"""
Underwater World farming script — Python version
Equivalent to: "farming in underwater world v1.3"

Configuration is read from a per-character .ini file.
On first run you'll be prompted to enter the filename.

Changes vs the original:
- Real Python variables, loops, and conditionals
- No JSON-embedded command strings
- Each section is a plain Python function — easy to read and edit
- Buff cooldown handled by set_interval(), not manual timing
- Full type hints and comments
"""

# The runner injects all mwbot API functions into this script's namespace,
# so no import is needed.  If you run the script directly during development,
# uncomment the line below:
# from mwbot import *

# ---------------------------------------------------------------------------
# User configuration  (edit these)
# ---------------------------------------------------------------------------
CREATE_TEAM = False          # Set True if you play healer and need a team
FUSION      = "Wind Spirit Guardian"   # Speed mount name, or None
USE_CARD    = True           # Pause/resume XP cards
USE_BUFF    = False          # Use a buff skill
BUFF_KEY    = "y"            # Key for the buff skill
BUFF_CD     = 300            # Buff cooldown in seconds
STONE       = None           # Teleport stone name when time runs out, or None
END_BEFORE  = 0              # Stop this many seconds before public hours end

# ---------------------------------------------------------------------------
# Determine character name and load their config
# ---------------------------------------------------------------------------
import pathlib
import os

# Focus the game window first
open_game_window()
sleep(1)

# Read character name from the game's status line (NVDA announces it)
# Press ` to get character info, capture first word
keypress("`")
match = wait_for(r"(\w+),", timeout=5)
username = match.group(1) if match else "player"
keypress("esc")
sleep(0.1)

# Load or create per-character config
cfg_file = pathlib.Path("scripts") / f"{username}_configuration.ini"
if cfg_file.exists():
    cfg_load(str(cfg_file))
    speak(f"Using configuration for {username}")
else:
    speak("No configuration saved. Type your configuration file name and press Enter.")
    config_name = entry("Configuration file name")
    cfg_set("config_file", config_name)
    cfg_load(config_name)
    speak(f"Configuration loaded: {config_name}")

sleep(1)

# ---------------------------------------------------------------------------
# Start buff interval if requested
# ---------------------------------------------------------------------------
if USE_BUFF:
    set_interval("buff", BUFF_KEY, BUFF_CD)
    speak("Buff interval started")

# ---------------------------------------------------------------------------
# Enable obstacles
# ---------------------------------------------------------------------------
enable_obstacles("collapsed statue", key="space")

# ---------------------------------------------------------------------------
# Detect starting map and route accordingly
# ---------------------------------------------------------------------------
speak("Detecting current map...")
keypress("e")
map_match = wait_for(r";(\d+);(\d+);(.+)$", timeout=5)

if not map_match:
    speak("Could not detect map. Make sure NVDA is running and the game is focused.")
    stop()
    raise SystemExit

map_name = map_match.group(3).strip().lower()
speak(f"Current map: {map_name}")

# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------

def mount():
    if FUSION:
        enable_mount(FUSION)
        sleep(1)


def go_to_underwater_world_from_mist_gods_ruins():
    """Walk from Mist Gods Ruins Temple to the Underwater World entrance."""
    speak("Navigating from Mist Gods Ruins...")
    mount()
    goposition(185, 197, speed=3)
    goposition(185, 389, speed=5)
    goposition(2, 389)
    go_through_cave()


def go_through_cave():
    """Navigate through the cave section."""
    speak("Entering cave...")
    # mapwall = large open area transition, just navigate to the exit
    goposition(65, 6)
    goposition(10, 127)
    goposition(2, 127)
    setup_team_and_farm()


def setup_team_and_farm():
    """Create a team if needed and start farming."""
    if CREATE_TEAM:
        speak("Creating team...")
        create_team()
        sleep(1)
    enable_regen()
    if cfg_bool("enable_pet", False):
        enable_pet_regen()
        enable_pet_food()
    start_farming()


def start_farming():
    """Main farming loop in the Underwater World."""
    speak("Starting farming loop")

    import threading
    _dead = threading.Event()

    def _on_death_callback(match):
        speak("Character died - stopping farming")
        _dead.set()
        disable_nav_attack()

    _death_handler = add_handler(r"^You were killed by", _on_death_callback)

    # Use the background nav-attack thread (same as farm.py)
    enable_nav_attack(timeout=0.08)

    try:
        while not _dead.is_set():
            check_abort()
            sleep(1.0)
    except SystemExit:
        pass
    finally:
        disable_nav_attack()
        remove_handler(_death_handler)


# ---------------------------------------------------------------------------
# Route to starting point based on current map
# ---------------------------------------------------------------------------

if "far off regions" in map_name or "mist gods ruins" in map_name:
    go_to_underwater_world_from_mist_gods_ruins()
elif "cave" in map_name or "aisle" in map_name:
    go_through_cave()
elif "underwater world" in map_name:
    setup_team_and_farm()
else:
    speak(f"Unsupported starting map: {map_name}")
    stop()
    raise SystemExit

# Clean up
del_interval("buff")
speak("Script finished.")
