"""
Go Back — navigate from farming area back to city center.

Uses goposition to walk to the city center coordinates set in config.ini.
Edit city_x and city_y to match your server's main city center.

Configuration (config.ini):
  [navigation]
  city_x=253
  city_y=181
"""

# mwbot API is automatically injected into the global namespace

TARGET_X = cfg_int("city_x", 253)
TARGET_Y = cfg_int("city_y", 181)

open_game_window()
sleep(1)

# Avoid getting stuck on common city NPCs
enable_obstacles(
    "Civilian Fanny",
    "Soul Storehouse",
    "Traveling Merchant",
    "Ansible Space-Time Storehouse",
    "Herb Buyer Benson",
    "Ansible Space-time marketplace",
    "Instructor Hargard",
    key="space",
)

speak(f"Navigating to city center ({TARGET_X}, {TARGET_Y})")
goposition(TARGET_X, TARGET_Y)

disable_obstacles()
speak("Arrived at city center.")
