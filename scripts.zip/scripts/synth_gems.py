"""
synth_gems.py — Synthesize gems and/or shards via Gem Craftsman NPC

Configure in config.ini:
    gem_synth_mode = gems        # "gems" or "shards" or "both"
    gem_synth_max_level = 6      # Don't synthesize gems above this level
"""

mode      = cfg_get("gem_synth_mode", "both").lower()
max_level = cfg_int("gem_synth_max_level", 6)

speak(f"Gem synthesis: mode={mode}, max_level={max_level}")

if mode in ("gems", "both"):
    speak("Synthesizing gems...")
    master_synth(max_level=max_level)

if mode in ("shards", "both"):
    speak("Synthesizing shards into gems...")
    master_synth_frag()

speak("Gem synthesis complete.")
