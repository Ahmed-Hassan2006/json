"""
Wolf Head Mountain Farming Script

Equivalent to premium bot "farming in wolf head v1.3".

Supports starting from:
  - Mist Gods Ruins / Far Off Regions (near temple entrance)
  - Cave / Aisle (mid-route)
  - Underwater World (already in farming zone, walk to Wolf Prairie/Wolf Head)
  - Wolf Prairie
  - Wolf Head Mountain (already at destination)

Features:
  - Auto-combat with nav-attack
  - Auto-health monitoring
  - Auto-bag clearing when overweight
  - Death recovery via mortal.py
  - Optional XP card pause/resume

Configuration (config.ini):
  [bot]
  use_cave = false
  xp_card = false

  [navigation]
  farm_bounds = 0,999,0,999

  [combat]
  ignore_mob =
"""

# mwbot API is automatically injected into the global namespace
import threading as _threading

USE_CARD = cfg_bool("xp_card", False)
FUSION   = cfg_get("fusion_speed", "")

open_game_window()
sleep(1)

enable_regen()
if cfg_bool("enable_pet", False):
    enable_pet_regen()
    enable_pet_food()

enable_obstacles("collapsed statue", "Guard", key="space")
enable_clearbag()

load_mapwall("Wolf Head Mountain")

# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------

def mount():
    if FUSION:
        enable_mount(FUSION)
        sleep(1)

def dismount():
    if FUSION:
        disable_mount()
        sleep(0.5)


def go_to_underwater_from_ruins():
    """Walk from Mist Gods Ruins Temple to the Underwater World entrance."""
    speak("Navigating from Mist Gods Ruins to Underwater World...")
    mount()
    goposition(185, 197, speed=3)
    goposition(185, 389, speed=5)
    goposition(2, 389)
    go_through_cave()


def go_through_cave():
    """Navigate through the cave section to the Underwater World."""
    speak("Navigating through cave...")
    goposition(65, 6)
    goposition(10, 127)
    goposition(2, 127)
    go_to_wolf_head_from_underwater()


def go_to_wolf_head_from_underwater():
    """Walk from Underwater World to Wolf Head Mountain via Wolf Prairie."""
    speak("Heading to Wolf Prairie...")
    mount()
    # TODO: Verify exact coordinates in-game for Wolf Prairie entrance
    goposition(200, 50)
    m = wait_for(r"Wolf Prairie|Wolf Head", timeout=20)
    if m and "wolf head" in m.group(0).lower():
        dismount()
        start_farming()
        return
    # Continue to Wolf Head Mountain from Wolf Prairie
    speak("Entering Wolf Head Mountain...")
    goposition(100, 100)
    m2 = wait_for(r"Wolf Head Mountain", timeout=20)
    if m2:
        speak("Arrived at Wolf Head Mountain")
    dismount()
    start_farming()


# ---------------------------------------------------------------------------
# Death recovery
# ---------------------------------------------------------------------------

_wh_recovery_done = _threading.Event()
_wh_recovery_done.set()

def _on_death_callback(match):
    # Guard: ignore if a recovery is already in progress
    if not _wh_recovery_done.is_set():
        return

    # Stop combat immediately — these are simple flag writes, safe to call
    # from the speech listener thread.
    _wh_recovery_done.clear()
    disable_nav_attack()
    stop_random_going()

    # Everything that needs speech (speak, wait_for, run_script …) must run
    # in a separate thread so we don’t block the NVDA speech listener.
    def _recover():
        try:
            speak("Died at Wolf Head Mountain - resurrecting")
            if USE_CARD:
                xp_card_pause()
            run_script("mortal.py")
            if USE_CARD:
                xp_card_resume()
            speak("Resuming Wolf Head farming")
            enable_nav_attack(timeout=0.08)
            start_farming_movement()
        finally:
            _wh_recovery_done.set()

    _t = _threading.Thread(target=_recover, daemon=True,
                           name="mwbot-death-recovery")
    _t.start()

_death_handler = add_handler(r"^You were killed by", _on_death_callback)


# ---------------------------------------------------------------------------
# Farming loop
# ---------------------------------------------------------------------------

def start_farming_movement():
    bounds = cfg_list("farm_bounds", fallback=[0, 999, 0, 999], cast=int)
    if len(bounds) == 4:
        set_movement_bounds(bounds[0], bounds[1], bounds[2], bounds[3])
    start_random_going(direction_update=cfg_float("direction_update_time", 3.0))


def start_farming():
    speak("Starting Wolf Head Mountain farming")
    enable_nav_attack(timeout=0.08)
    start_farming_movement()


# ---------------------------------------------------------------------------
# Route from current map
# ---------------------------------------------------------------------------

speak("Detecting current map...")
keypress("e")
map_match = wait_for(r";(\d+);(\d+);(.+)$", timeout=5)

if not map_match:
    speak("Could not detect map. Make sure NVDA is running.")
    stop()
    raise SystemExit

map_name = map_match.group(3).strip().lower()
speak(f"Current map: {map_name}")

if "far off regions" in map_name or "mist gods ruins" in map_name:
    go_to_underwater_from_ruins()
elif "cave" in map_name or "aisle" in map_name:
    go_through_cave()
elif "underwater world" in map_name:
    go_to_wolf_head_from_underwater()
elif "wolf prairie" in map_name:
    # Already in Wolf Prairie — continue to Wolf Head
    speak("In Wolf Prairie, heading to Wolf Head Mountain...")
    mount()
    goposition(100, 100)
    wait_for(r"Wolf Head Mountain", timeout=20)
    dismount()
    start_farming()
elif "wolf head" in map_name:
    start_farming()
else:
    speak(f"Unsupported starting map: {map_name}. Attempting farming anyway.")
    start_farming()

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

try:
    while True:
        check_abort()
        sleep(1.0)
except SystemExit:
    pass
finally:
    speak("Wolf Head farming script shutting down...")
    disable_nav_attack()
    stop_random_going()
    disable_clearbag()
    clear_obstacles()
    remove_handler(_death_handler)
    clear_handlers()
