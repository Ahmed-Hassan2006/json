"""
Skeleton Basin Farming Script

Supports starting from:
  - High Climbing Grassland (inside Holy Blood City)
  - Black Wasteland (already near the basin)
  - Skeleton Basin (already farming area)
  - Skull Cave (cave area for farming during Lich King events)

Features:
  - Auto-combat with nav-attack
  - Auto-health monitoring
  - Auto-bag clearing when overweight
  - Death recovery via mortal.py
  - Lich King event detection (optional cave mode)
  - XP card pause/resume on death

Configuration (config.ini):
  [navigation]
  farm_bounds = 0,999,0,999     # x1,x2,y1,y2 bounding box for random movement

  [combat]
  ignore_mob = Lich King        # Comma-separated mobs to skip (Lich King recommended)

  [bot]
  use_cave = false              # Set true to farm Skull Cave during Lich King event
  xp_card = false               # Set true to pause XP card on death
"""

# mwbot API is automatically injected into the global namespace

USE_CAVE = cfg_bool("use_cave", False)
USE_CARD = cfg_bool("xp_card", False)
FUSION   = cfg_get("fusion_speed", "")   # Mount name, or empty for none

open_game_window()
sleep(1)

enable_regen()
if cfg_bool("enable_pet", False):
    enable_pet_regen()
    enable_pet_food()

# Skip Lich King — fighting him as a solo player is dangerous
ignore_mob("Lich King")

enable_obstacles("collapsed statue", "Guard", "Traveling Merchant", key="space")
enable_clearbag()

load_mapwall("Skeleton Basin")

# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------

def mount():
    if FUSION:
        enable_mount(FUSION)
        sleep(1)

def dismount():
    if FUSION:
        disable_mount()
        sleep(0.5)


def go_to_skeleton_basin_from_city():
    """Walk from Holy Blood City to Skeleton Basin entrance."""
    speak("Navigating to Skeleton Basin from city...")
    mount()
    # Walk east out of city toward Black Wasteland
    goposition(402, 165)
    # Enter Skeleton Basin area
    go_to_skeleton_basin_from_wasteland()


def go_to_skeleton_basin_from_wasteland():
    """Walk from Black Wasteland into Skeleton Basin."""
    speak("Entering Skeleton Basin...")
    mount()
    goposition(200, 200)
    m = wait_for(r"Skeleton Basin", timeout=20)
    if not m:
        speak("Could not confirm entry into Skeleton Basin")
    dismount()
    start_farming()


def go_to_skull_cave():
    """Navigate to Skull Cave for Lich King event farming."""
    speak("Heading to Skull Cave...")
    # TODO: Verify exact cave entrance coordinates in-game
    goposition(100, 50)
    m = wait_for(r"Skull Cave", timeout=20)
    if m:
        speak("Entered Skull Cave")
    start_farming()


# ---------------------------------------------------------------------------
# Lich King event detection
# ---------------------------------------------------------------------------

if USE_CAVE:
    @on_speech(r"^broadcast ;Lich King:")
    def _on_lich_king_event(match):
        speak("Lich King event detected - going to Skull Cave")
        disable_nav_attack()
        stop_random_going()
        go_to_skull_cave()


# ---------------------------------------------------------------------------
# Death recovery
# ---------------------------------------------------------------------------

def _on_death_callback(match):
    speak("Died in Skeleton Basin - resurrecting")
    disable_nav_attack()
    stop_random_going()
    if USE_CARD:
        xp_card_pause()
    run_script("mortal.py")
    if USE_CARD:
        xp_card_resume()
    speak("Resuming Skeleton Basin farming")
    enable_nav_attack(timeout=0.08)
    start_farming_movement()

_death_handler = add_handler(r"^You were killed by", _on_death_callback)


# ---------------------------------------------------------------------------
# Farming loop
# ---------------------------------------------------------------------------

def start_farming_movement():
    """Start random navigation within configured bounds."""
    bounds = cfg_list("farm_bounds", fallback=[0, 999, 0, 999], cast=int)
    if len(bounds) == 4:
        set_movement_bounds(bounds[0], bounds[1], bounds[2], bounds[3])
    start_random_going(direction_update=cfg_float("direction_update_time", 3.0))


def start_farming():
    """Enable combat and start farming movement."""
    speak("Starting Skeleton Basin farming")
    enable_nav_attack(timeout=0.08)
    start_farming_movement()


# ---------------------------------------------------------------------------
# Route from current map
# ---------------------------------------------------------------------------

speak("Detecting current map...")
keypress("e")
map_match = wait_for(r";(\d+);(\d+);(.+)$", timeout=5)

if not map_match:
    speak("Could not detect map. Make sure NVDA is running.")
    stop()
    raise SystemExit

map_name = map_match.group(3).strip().lower()
speak(f"Current map: {map_name}")

if "high climbing grassland" in map_name or "holy blood city" in map_name:
    go_to_skeleton_basin_from_city()
elif "black wasteland" in map_name:
    go_to_skeleton_basin_from_wasteland()
elif "skull cave" in map_name:
    start_farming()
elif "skeleton basin" in map_name:
    start_farming()
else:
    speak(f"Unsupported starting map: {map_name}. Attempting farming anyway.")
    start_farming()

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

try:
    while True:
        check_abort()
        sleep(1.0)
except SystemExit:
    pass
finally:
    speak("Skeleton Basin script shutting down...")
    disable_nav_attack()
    stop_random_going()
    disable_clearbag()
    clear_obstacles()
    remove_handler(_death_handler)
    clear_handlers()
