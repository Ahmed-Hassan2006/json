"""
sell_fragments.py — Sell shards/fragments to the Shard Broker NPC

Configure which fragments to sell in config.ini:
    fragstor = Equipment Enhance Crystal Shard|Weapon Enhance Crystal Shard

Or pass names directly when running from another script:
    run_script("sell_fragments.py")
"""

frag_names = cfg_list("fragstor", sep="|", fallback=[])

if not frag_names:
    speak("No fragment names configured. Set 'fragstor' in config.ini.")
else:
    speak(f"Selling fragments: {', '.join(frag_names)}")
    sell_fragments(*frag_names)
    speak("Fragment selling complete.")
