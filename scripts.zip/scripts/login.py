"""
Login automation script — Python version
Equivalent to premium bot's 'login' script.

Finds the login screen, selects the character, and sets up combat defaults.
"""

# mwbot API is injected by the runner — no imports needed

open_game_window()
sleep(1)

# Step 1: Find and press "Log in" button
speak("Looking for login button...")
for attempt in range(30):
    keypress("w")
    sleep(0.3)
    text = last_spoken()
    if "log in" in text.lower():
        sleep(0.5)
        keypress("enter")
        speak("Logging in...")
        break
else:
    speak("Could not find login button")
    stop()
    raise SystemExit

sleep(0.5)

# Step 2: Select character from list
# Character entries look like: "Alyaseen;Warrior;last access: Apr 25, 10:20:43, 2026; delete character"
# Navigate using W/S to find your character, then press Enter.
# game_strings confirmed format: "Name;Class;last access: date; delete character"
_CHAR_ENTRY_RE = r"^(.+);(.+);last access: (.+); delete character$"
char_name = cfg_get("character_name", "").lower()
speak(f"Selecting character{': ' + char_name if char_name else ''}...")
found_char = False
for attempt in range(20):
    text = last_spoken()
    import re as _re
    if _re.match(_CHAR_ENTRY_RE, text, _re.IGNORECASE):
        if not char_name or char_name in text.lower():
            found_char = True
            keypress("enter")
            speak("Character selected.")
            break
    keypress("s")
    sleep(0.3)

if not found_char:
    # Fallback: press Enter wherever we are
    speak("Could not find character by name — pressing Enter on current selection.")
    keypress("enter")

sleep(0.5)

# Step 3: Wait for the world to load (position is announced when map loads)
speak("Waiting for world to load...")
m = wait_for(r"^[^;]+;[^;]+;\d{1,3};\d{1,3};.+$", timeout=30)
if m:
    speak("World loaded.")
else:
    speak("Warning: could not confirm world load — continuing anyway.")
sleep(1.0)

# Step 4: Set combat defaults
speak("Setting combat defaults...")

# Set mode to "enemies" (press V until NVDA says "enemies")
for _ in range(10):
    keypress("v")
    sleep(0.2)
    if "enemies" in last_spoken().lower():
        break

# Set combat mode to "pacifist mode with counterattack"
for _ in range(10):
    keypress("b")
    sleep(0.2)
    if "pacifist mode with counterattack" in last_spoken().lower():
        break

speak("Login complete")
