"""
Universal Farming Script — mwbot_free

This script ties together navigation, combat, looting, and death recovery into a single autonomous loop.
It uses 'random going' by default, meaning it wanders the map finding enemies to kill.

Features:
- Auto-attacks enemies (via background thread)
- Auto-navigates (randomly within bounds)
- Auto-clears bag when overweight
- Auto-resurrects on death
- Auto-bypasses common obstacles
"""

# mwbot API is automatically injected into the global namespace

speak("Starting Universal Farming Script...")

# 1. Setup Obstacles
# These are common walls/NPCs that the bot might get stuck on. It will press space to jump/bypass them.
enable_obstacles("collapsed statue", "mountain wall", "Guard", "Traveling Merchant", key="space")

# 2. Enable Health Monitoring
# Without this call, the background health thread does nothing (regen is off by default).
enable_regen()
if cfg_bool("enable_pet", False):
    enable_pet_regen()
    enable_pet_food()

# 3. Setup Bag Management
# If NVDA says "overweight", this triggers clear_bag() using your clearbag.txt list
enable_clearbag()

# 4. Setup Death Recovery
def on_death(match):
    speak("Death detected. Pausing combat and running mortal script.")
    disable_nav_attack()
    stop_random_going()

    # Run the resurrection script
    run_script("mortal.py")

    # Resume farming after resurrection
    speak("Resuming farming after death.")
    enable_nav_attack(timeout=0.08)
    start_random_going(direction_update=3.5)

# Correct game text: "You were killed by <enemy name>"
add_handler(r"^You were killed by", on_death)

# 4. Turn on Combat
# This starts a background thread that constantly presses nav keys (k,o,;,l) to find enemies,
# checks your ignored_mobs list, and presses your attack key (h).
speak("Engaging combat mode.")
enable_nav_attack(timeout=0.08)

# 5. Start Navigation (Random Walking)
# We read the boundaries from config.ini. If none exist, we default to the whole map.
bounds = cfg_list("farm_bounds", fallback=[0, 999, 0, 999], cast=int)
if len(bounds) == 4:
    set_movement_bounds(bounds[0], bounds[1], bounds[2], bounds[3])
    start_random_going(direction_update=3.5)
    speak("Random navigation started.")
else:
    speak("Error with farm_bounds in config. Please set x1, x2, y1, y2.")

# 6. Main Loop
# The script stays alive here while the background threads do the work.
# If you press 'Stop Script' in the GUI (or Alt+Tab), the check_abort() mechanism inside sleep() handles it!
try:
    while True:
        # Check XP control if enabled
        # (This is a 1-second loop that keeps the main thread alive)
        sleep(1.0)
except SystemExit:
    pass # Caught a GUI 'Stop' or Alt+Tab abort
finally:
    # Cleanup everything gracefully
    speak("Farming script shutting down...")
    disable_nav_attack()
    stop_random_going()
    disable_clearbag()
    clear_obstacles()
    clear_handlers()
