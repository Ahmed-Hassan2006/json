Translate map names into your language
To use auto-navigation (the `goposition` function), you need to create or obtain a ready-made terrain map. I create obstacle maps to the best of my abilities. The current archive of maps can be found in the bot's file exchange. My maps are created in the Chinese version, so you need to rename them and place them in the `map.wall` folder.
I'll explain how to use obstacle maps in your scripts. There are two ways to use them.
To have the bot automatically use the terrain map, you must name it exactly as it is in your game. For example, check the coordinates:
Rock Square;Giant Rock City;204;195;central plains
The name of this terrain map is: central plains
If there is a file named `central plains` in the `map.wall` folder, the bot will get the list of obstacle coordinates from it. If you have a different file name, you should connect it in the script using the command:
`mapwall=YourFilename`
If you don't do any of this, don't be surprised if your character runs into walls and gets stuck.

Short description
bosspinokio
This file contains the coordinates of the obstacles on the map where the Pinocchio boss appears. if you want the character to automatically find the route to the boss, this map must be connected as soon as the character enters this map. The first and second floors of the factory have the same name and there will be a conflict of barriers.

faraon
this file contains the coordinates of the obstacles on the map where the boss Pharaoh appears
if you want the character to automatically find the route to the boss, this map must be connected as soon as the character enters this map. The second and third floors of the tomb have the same name and a conflict of barriers will occur.

Flaming Mountain
coordinates of obstacles on the fiery mountain

一号升降平台
coordinates of the walls near the caves for 1, 3 and 5 players

中央平原
central plains. a rock city and a village are drawn in the northwest, where there is a soldier. southeastern village, probably not

千里长河
map where the scorpion cave is located for level 60

卡特部落
map of walls on the way to boss Elvis

喀斯特山洞
coordinates of obstacles in a karst cave. Not all the walls were drawn, I did it specifically for the route to the pharaoh

土克拉迷窟
coordinates of the walls on the way to the wild tyrant boss

多米荒原
I don’t remember where this map is, I hope you can determine it yourself

奥克斯部落
the first map on the way to the wild tyrant, I hope I drew all the houses

巨岩城地下
rock city dungeon

帮派驻地
coordinates of the walls at the gang station. the coordinates of the walls at the gang water station are a little different, I didn't do that

废弃工厂
coordinates of the walls of an abandoned factory

斯派克荒原
coordinates of the walls of the thorny wastelands. level 90 boss. the old house is not drawn

斯科勒盆地
coordinates of the walls of the lich map. no cave, this is a separate map

无底洞
if I remember correctly, these are the coordinates of the walls of the level 80 experience cave

春光村
game event map, this may happen again sometime in the future.

水帘洞
coordinates of the cave walls where the entrance to the level 40 spider cave and the entrance to the level 45 mission, boars, are located.

水色山光
coordinates of the walls in the river, route to the level 40 experience cave

沃尔夫草原
wolf prairie, only one wall is drawn so that the character does not hit the wall on the way to the boss Elvis

沃野之乡
coordinates of the walls of the village where we do bandit missions, the city of white sand is minimally drawn

活尸洞
coordinates of the walls in the cave of corpses, made the correct passage along the route to the pharaoh

海底世界
map of walls in the underwater world. Level 100.

海角天涯
coordinates of the walls of the map of the sea in which the island is located. the island itself is not drawn very well, I only drew the coordinates of the temple

猫王别墅
Coordinates of the walls of Elvis's villa

神秘墓穴
coordinates of the walls of the second floor of the pharaoh's tomb

血红城堡
coordinates of the walls of Dracula's castle. Level 100

赤血荒地
coordinates of the walls of the first floor of Dracula's castle

雷云洞
coordinates of the walls of the map, which is located in front of the place where the level 80 boss lives, which gives materials for level 80 equipment.

马鲁艾盆地
coordinates of the walls of the first city

高攀草原
coordinates of the walls of the city of the holy blood, you can get there by underground cable car from level 60

黑暗神庙
coordinates of the walls in the temple of the dark priest, level 100 boss

黑森林
coordinates of the walls around the temple where the dark priest lives

黑色荒地
coordinates of the walls in the city of the dark night, from here the route to the lich and to the dark priest begins