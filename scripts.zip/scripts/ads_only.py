"""
Broadcast-only mode — NO farming.

Run this when your farming time is done but you still want the global-channel
messages (gang recruit + the sale/trade ads) to keep going out on schedule,
and the auto-reply to keep answering private messages.

The broadcaster and the auto-reply are BOT-LEVEL features that mwbot.start()
turns on from config.ini ([chat] gang_recruit / auto_reply), so this script
does NOT enable combat, movement, healing, or any map logic — it just keeps
the game window focused and the process alive so those background threads
keep running.  One message goes out every [chat] broadcast_interval_min
minutes, rotating through gang_recruit_text then each broadcast_extra.

Usage:
    python run.py scripts/ads_only.py
    (or pick "ads_only" in the bot GUI's Scripts tab)

Stop it any time with Ctrl+F2 (GUI) / Ctrl+C (console).  Leave the game
window focused so the messages can actually type into the chat box.
"""

open_game_window()

if not cfg_bool("gang_recruit", False):
    speak("Warning: gang recruit is off in config. No messages will be sent. "
          "Set gang_recruit to true in the chat section of config.")
else:
    _mins = cfg_int("broadcast_interval_min", 45)
    speak(f"Broadcast only mode. Farming is off. One message every {_mins} "
          f"minutes. Keep the game window focused.")

# Idle forever so the process (and its broadcaster + auto-reply threads) stays
# alive.  sleep() calls check_abort() internally, so Ctrl+F2 / a stop still
# ends the script cleanly; a focus loss pauses the broadcaster on its own.
try:
    while True:
        sleep(30)
except SystemExit:
    pass
