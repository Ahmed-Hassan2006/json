"""
Fishing automation script.

Stand near a fishing spot with your rod equipped and run this script.
The game sends fishing-related events via NVDA speech which the bot monitors.

When the bag becomes overweight, the bot automatically runs sell_fish.py to
sell the catch at the nearest Aquaculture Buyer NPC and then returns to fishing.

Configuration (config.ini):
  [combat]
  # No extra config needed for basic fishing

  [health]
  # (Optional) Enable regen so HP/MP are maintained while fishing
  # min_hp, min_mp, key_regen_hp, key_regen_mp as usual
"""

# mwbot API is automatically injected into the global namespace

enable_regen()

speak("Fishing mode active.")

# Watch for overweight — sell fish and come back
@on_speech(r"^overweight$")
def _handle_overweight(match):
    speak("Bag full. Selling fish...")
    run_script("sell_fish.py")
    speak("Done selling. Resuming fishing.")

# Main loop — stays alive while the fish arrive
try:
    while True:
        check_abort()
        sleep(1.0)
except SystemExit:
    pass
finally:
    clear_handlers()
    disable_regen()
    speak("Fishing script stopped.")
