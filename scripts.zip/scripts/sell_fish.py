"""
sell_fish.py — Sell all fish/shrimp to the Aquaculture Buyer NPC

The NPC must be nearby. The script presses Enter on the NPC,
scrolls through available fish with S, and sells each one.
"""

speak("Selling fish to Aquaculture Buyer...")
result = sell_collection("fish")
if result:
    speak("Fish sold successfully.")
else:
    speak("Fish selling failed or no fish to sell.")
