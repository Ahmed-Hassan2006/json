# mwbot script â€” API is injected automatically
# Type your code below

speak('Hello from ' + __file__)
