"""
Wall mapper — dedicated EXPLORE-ONLY mode to build a complete wall file.

Use this on a NEW map that has no reference wall file yet (maps that already
have a made/reference file, like Margit Rainforest's monkey1, do NOT need
this — just use the reference).  It does NOT farm or kill: it only walks the
whole reachable map, tile by tile, so the wall recorder learns every wall,
then writes a full wall file like the reference ones.  Regen/heal stays on so
it survives; if it dies it auto-resurrects and continues.

HOW TO USE
----------
1. Put your character IN the map you want to map, logged in.
2. Set REGION below to that map's exact name (what E announces as the last
   position field), and BOUNDS to a box that safely contains it — the default
   (0..400) is fine for most maps; the explorer only ever visits reachable
   ground, so a too-big box costs nothing.
3. Run it and leave it — it can take HOURS for a big map (this is a one-time
   job).  It announces "Map exploration complete. Wall file written." when the
   whole reachable area is mapped, then you can stop it.
4. The file lands at scripts/wall/<REGION>, same format as the reference maps.

    python run.py scripts/wall_mapper.py
"""

# ===== EDIT THESE for the map you are mapping =====================
REGION = "Margit Rainforest"      # exact map name (E's last field)
BOUNDS = (0, 400, 0, 400)         # safe box around the map (x0,x1,y0,y1)
# A known damage hazard to flee while mapping (x0,x1,y0,y1), or None.
# Margit's Poison Swamp; set None for a map with no hazard.
HAZARD = (4, 51, 189, 235)
# =================================================================

open_game_window()
speak(f"Wall mapper for {REGION}. Exploration only, no farming.")

# Survival only — regen/heal + pet, close stray menus, auto-resurrect.
# NO combat is armed: this mode never fights.
enable_regen()
enable_pet_regen()
enable_pet_food()
enable_auto_close_menus()
enable_auto_resurrect()

# Learn walls live and write scripts/wall/<REGION>.
enable_wall_recording(REGION, live=True)
load_mapwall(REGION)

# Flee the hazard so the character doesn't die standing in it while mapping.
if HAZARD:
    enable_hazard_escape(HAZARD, clearance=2, region=REGION)

# Force one position read so we know where we are before exploring.
keypress("e")
wait_for(r"(\d+);(\d+);([^;]+)$", timeout=3.0)

try:
    map_explorer(REGION, bounds=BOUNDS)
    speak("Wall mapper finished.")
except SystemExit:
    pass
finally:
    disable_hazard_escape()
    disable_wall_recording()   # final flush + compile of scripts/wall/<REGION>
    disable_auto_resurrect()
    disable_auto_close_menus()
