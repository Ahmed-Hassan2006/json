package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val OceanTeal = Color(0xFF0D686D)
val MintGreen = Color(0xFF32938B)
val SunsetGold = Color(0xFFDF802E)

val OceanTealDark = Color(0xFF1BE1EB)
val MintGreenDark = Color(0xFF5ED3C9)
val SunsetGoldDark = Color(0xFFFFAE66)

val SageLightBackground = Color(0xFFFAFCFC)
val SageDarkBackground = Color(0xFF0F1517)
val CardLightBg = Color(0xFFFFFFFF)
val CardDarkBg = Color(0xFF182226)

val PriorityHigh = Color(0xFFD32F2F)
val PriorityMedium = Color(0xFFE65100)
val PriorityLow = Color(0xFF388E3C)

