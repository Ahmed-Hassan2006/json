package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppDatabase
import com.example.data.TaskEntity
import com.example.data.TaskRepository
import com.example.ui.SortOrder
import com.example.ui.TaskUiState
import com.example.ui.TaskViewModel
import com.example.ui.TaskViewModelFactory
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(this)
        val repository = TaskRepository(database.taskDao())
        val viewModel: TaskViewModel by viewModels {
            TaskViewModelFactory(repository)
        }

        setContent {
            MyApplicationTheme {
                val snackbarHostState = remember { SnackbarHostState() }
                
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    TaskPlannerScreen(
                        viewModel = viewModel,
                        snackbarHostState = snackbarHostState,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TaskPlannerScreen(
    viewModel: TaskViewModel,
    snackbarHostState: SnackbarHostState,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedPriority by viewModel.selectedPriority.collectAsStateWithLifecycle()
    val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<TaskEntity?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Standard lists
    val categories = listOf("الكل", "عمل", "شخصي", "دراسة", "صحة", "أخرى")
    val priorities = listOf("الكل", "عاجل جداً", "متوسط", "عادي")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Premium Header
        PlannerAppBar(
            onAddClick = { showAddDialog = true }
        )

        // Statistics Widget (Daily Rate)
        AnimatedVisibility(
            visible = uiState is TaskUiState.Success,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            if (uiState is TaskUiState.Success) {
                val state = uiState as TaskUiState.Success
                StatsCard(
                    completionRate = state.completionRate,
                    completedCount = state.completedCount,
                    totalCount = state.totalCount
                )
            }
        }

        // Search and Filters Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .semantics(mergeDescendants = true) {
                    contentDescription = "شريط البحث وتصفية المهام"
                },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // Search Text Field
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        placeholder = { Text("ابحث عن المهام اليومية...", fontSize = 14.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "أيقونة البحث",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "مسح نص البحث",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_input"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // Sort Menu
                    Box {
                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier.semantics { contentDescription = "خيارات الفرز" }
                        ) {
                            Icon(Icons.Default.Sort, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("الأحدث ترتيبًا تنازليًا") },
                                onClick = { viewModel.selectSort(SortOrder.DATE_DESC); showSortMenu = false },
                                trailingIcon = { if (selectedSort == SortOrder.DATE_DESC) Icon(Icons.Default.Check, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("الأقدم ترتيبًا تصاعديًا") },
                                onClick = { viewModel.selectSort(SortOrder.DATE_ASC); showSortMenu = false },
                                trailingIcon = { if (selectedSort == SortOrder.DATE_ASC) Icon(Icons.Default.Check, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("الأولوية القصوى أولاً") },
                                onClick = { viewModel.selectSort(SortOrder.PRIORITY_HIGH_FIRST); showSortMenu = false },
                                trailingIcon = { if (selectedSort == SortOrder.PRIORITY_HIGH_FIRST) Icon(Icons.Default.Check, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("أبجديًا") },
                                onClick = { viewModel.selectSort(SortOrder.NAME_ASC); showSortMenu = false },
                                trailingIcon = { if (selectedSort == SortOrder.NAME_ASC) Icon(Icons.Default.Check, null) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Categories Slider
                Text(
                    text = "التصنيف حسب المجموعة",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    textAlign = TextAlign.Start
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = cat == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectCategory(cat) },
                            label = { Text(cat) },
                            leadingIcon = {
                                Icon(
                                    imageVector = getCategoryIcon(cat),
                                    contentDescription = null, // decorative
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .testTag("category_chip_${cat}")
                                .semantics { 
                                    contentDescription = "تصنيف $cat" 
                                    stateDescription = if (isSelected) "محدد" else "غير محدد"
                                }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Priority filters
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "الأولوية:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        priorities.forEach { prio ->
                            val isSelected = prio == selectedPriority
                            AssistChip(
                                onClick = { viewModel.selectPriority(prio) },
                                label = { Text(prio, fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
                                    labelColor = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier
                                    .testTag("priority_chip_${prio}")
                                    .semantics { 
                                        contentDescription = "أولوية $prio" 
                                        stateDescription = if (isSelected) "محددة" else "غير محددة"
                                    }
                            )
                        }
                    }
                }
            }
        }

        // Active Tasks List Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (val state = uiState) {
                is TaskUiState.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                            .semantics { contentDescription = "جاري تحميل المهام" },
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                is TaskUiState.Success -> {
                    if (state.tasks.isEmpty()) {
                        EmptyStateView(
                            onAddClick = { showAddDialog = true }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(state.tasks, key = { it.id }) { task ->
                                val dismissState = rememberSwipeToDismissBoxState(
                                    confirmValueChange = { dismissValue ->
                                        if (dismissValue == SwipeToDismissBoxValue.EndToStart || dismissValue == SwipeToDismissBoxValue.StartToEnd) {
                                            viewModel.deleteTask(task)
                                            coroutineScope.launch {
                                                val result = snackbarHostState.showSnackbar(
                                                    message = "تم حذف المهمة",
                                                    actionLabel = "تراجع",
                                                    duration = SnackbarDuration.Short
                                                )
                                                if (result == SnackbarResult.ActionPerformed) {
                                                    viewModel.undoDelete()
                                                }
                                            }
                                            true
                                        } else {
                                            false
                                        }
                                    }
                                )

                                SwipeToDismissBox(
                                    state = dismissState,
                                    backgroundContent = {
                                        val color by animateColorAsState(
                                            when (dismissState.targetValue) {
                                                SwipeToDismissBoxValue.Settled -> Color.Transparent
                                                else -> MaterialTheme.colorScheme.errorContainer
                                            }
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(color, RoundedCornerShape(18.dp))
                                                .padding(horizontal = 20.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            if (dismissState.targetValue != SwipeToDismissBoxValue.Settled) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "حذف المهمة",
                                                    tint = MaterialTheme.colorScheme.onErrorContainer,
                                                    modifier = Modifier.size(28.dp)
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.animateItem(placementSpec = spring())
                                ) {
                                    TaskItemCard(
                                        task = task,
                                        onToggle = { isChecked ->
                                            viewModel.toggleTask(task.id, isChecked)
                                        },
                                        onEdit = { taskToEdit = task },
                                        onDelete = { 
                                            viewModel.deleteTask(task)
                                            coroutineScope.launch {
                                                val result = snackbarHostState.showSnackbar(
                                                    message = "تم حذف المهمة",
                                                    actionLabel = "تراجع",
                                                    duration = SnackbarDuration.Short
                                                )
                                                if (result == SnackbarResult.ActionPerformed) {
                                                    viewModel.undoDelete()
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal adding form
    if (showAddDialog) {
        TaskFormDialog(
            title = "إضافة مهمة جديدة",
            onDismiss = { showAddDialog = false },
            onSubmit = { title, desc, cat, prio, date ->
                viewModel.addTask(title, desc, cat, prio, date)
                showAddDialog = false
            }
        )
    }

    // Modal editing form
    if (taskToEdit != null) {
        val task = taskToEdit!!
        TaskFormDialog(
            title = "تعديل مهمة",
            initialTask = task,
            onDismiss = { taskToEdit = null },
            onSubmit = { title, desc, cat, prio, date ->
                viewModel.updateTask(
                    task.copy(
                        title = title,
                        description = desc,
                        category = cat,
                        priority = prio,
                        dueDate = date
                    )
                )
                taskToEdit = null
            }
        )
    }
}

@Composable
fun PlannerAppBar(
    onAddClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
                    )
                )
            )
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "مُخطط المهام اليومية",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "رتب حياتك بخطوات بسيطة وفعالة ✍️",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )
            }

            IconButton(
                onClick = onAddClick,
                modifier = Modifier
                    .background(Color.White, shape = CircleShape)
                    .size(46.dp)
                    .testTag("appbar_add_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Task",
                    tint = OceanTeal,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun StatsCard(
    completionRate: Float,
    completedCount: Int,
    totalCount: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, start = 16.dp, end = 16.dp, bottom = 8.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "معدل الإنجاز لليوم",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Text(
                    text = "$completedCount من أصل $totalCount مهام منجزة",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { completionRate },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.15f)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Percentage Circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(64.dp)
            ) {
                CircularProgressIndicator(
                    progress = { completionRate },
                    modifier = Modifier.fillMaxSize(),
                    strokeWidth = 6.dp,
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.1f)
                )
                Text(
                    text = "${(completionRate * 100).toInt()}%",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

@Composable
fun TaskItemCard(
    task: TaskEntity,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()) }
    val formattedDate = formatter.format(Date(task.dueDate))

    val borderStroke = if (task.isCompleted) {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    } else {
        BorderStroke(1.5.dp, getPriorityColor(task.priority).copy(alpha = 0.4f))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}")
            .semantics {
                // A clean read-out for TalkBack encompassing all key data
                val stateDesc = if (task.isCompleted) "حالة المهمة: مُنجزة" else "حالة المهمة: قيد الانتظار"
                val descText = if (task.description.isNotEmpty()) ". التفاصيل: ${task.description}" else ""
                contentDescription = "$stateDesc. عنوان المهمة: ${task.title}$descText. الصنف: ${task.category}. الأولوية: ${task.priority}. تاريخ التسليم: $formattedDate"
            },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = borderStroke,
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (task.isCompleted) 0.dp else 2.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Status Indicator
                IconButton(
                    onClick = { onToggle(!task.isCompleted) },
                    modifier = Modifier.testTag("task_checkbox_${task.id}")
                        .semantics { role = Role.Checkbox; stateDescription = if (task.isCompleted) "محدّد" else "غير محدّد" }
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = if (task.isCompleted) "تحديد المهمة كغير منجزة" else "تحديد المهمة كمنجزة",
                        tint = if (task.isCompleted) MaterialTheme.colorScheme.primary else getPriorityColor(task.priority),
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Task Details Text (cross-out if complete)
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = task.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface,
                        textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                        textAlign = TextAlign.Start,
                        modifier = Modifier.clearAndSetSemantics { } // hidden since parent reads it
                    )
                    if (task.description.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = task.description,
                            fontSize = 13.sp,
                            color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            maxLines = 2,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.clearAndSetSemantics { } // hidden since parent reads it
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer of Task Card
            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                thickness = 1.dp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth().clearAndSetSemantics { }, // Parent reads this info
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Category + Date + Priority chips
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Category icon pill
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = getCategoryIcon(task.category),
                                contentDescription = null,
                                modifier = Modifier.size(12.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = task.category,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Priority label pill
                    Box(
                        modifier = Modifier
                            .background(
                                color = getPriorityColor(task.priority).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = task.priority,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = getPriorityColor(task.priority)
                        )
                    }

                    // Date text
                    Text(
                        text = "📅 $formattedDate",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }

                // Action controls (Edit, Delete)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.semantics(mergeDescendants = true) {} // Allow inner buttons to be selectable or we can add them to a single semantic container
                ) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp).semantics { contentDescription = "تعديل المهمة" }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).semantics { contentDescription = "حذف المهمة" }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateView(
    onAddClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // High Quality AI Generated Workspace Image Asset
        Card(
            modifier = Modifier
                .size(width = 240.dp, height = 180.dp)
                .clip(RoundedCornerShape(20.dp)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_tasks),
                contentDescription = "Empty plan notebook illustration",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "دفترك اليومي فارغ تماماً!",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "ابدأ بجدولة أهدافك ومخططاتك اليومية والعملية الآن لزيادة إنتاجيتك وتنظيم مهامك بكفاءة.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            lineHeight = 20.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onAddClick,
            shape = RoundedCornerShape(16.dp),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("أضف أول موضوع / مهمة")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskFormDialog(
    title: String,
    initialTask: TaskEntity? = null,
    onDismiss: () -> Unit,
    onSubmit: (title: String, description: String, category: String, priority: String, dueDate: Long) -> Unit
) {
    var taskTitle by remember { mutableStateOf(initialTask?.title ?: "") }
    var taskDesc by remember { mutableStateOf(initialTask?.description ?: "") }
    var taskCat by remember { mutableStateOf(initialTask?.category ?: "عمل") }
    var taskPrio by remember { mutableStateOf(initialTask?.priority ?: "متوسط") }
    var taskDate by remember { mutableStateOf(initialTask?.dueDate ?: System.currentTimeMillis()) }

    var isTitleError by remember { mutableStateOf(false) }

    val categories = listOf("عمل", "شخصي", "دراسة", "صحة", "أخرى")
    val priorities = listOf("عاجل جداً", "متوسط", "عادي")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Title Input
                Text(
                    text = "عنوان المهمة *",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
                OutlinedTextField(
                    value = taskTitle,
                    onValueChange = {
                        taskTitle = it
                        if (it.isNotEmpty()) isTitleError = false
                    },
                    placeholder = { Text("مثال: مراجعة العرض التقديمي", fontSize = 14.sp) },
                    isError = isTitleError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("dialog_title_input"),
                    shape = RoundedCornerShape(12.dp)
                )
                if (isTitleError) {
                    Text(
                        text = "يرجى كتابة عنوان للمهمة لكي تتمكن من حفظها.",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Description Input
                Text(
                    text = "تفاصيل إضافية (اختياري)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
                OutlinedTextField(
                    value = taskDesc,
                    onValueChange = { taskDesc = it },
                    placeholder = { Text("اكتب ملاحظاتك ومواعيد التسليم هنا...", fontSize = 13.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .height(80.dp)
                        .testTag("dialog_desc_input"),
                    shape = RoundedCornerShape(12.dp),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.Description,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline
                        )
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Category Selection
                Text(
                    text = "اختيار تصنيف المهمة",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = taskCat == cat,
                            onClick = { taskCat = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = getCategoryIcon(cat),
                                    contentDescription = cat,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            modifier = Modifier.testTag("dialog_category_${cat}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Priority Selection
                Text(
                    text = "مستوى الأهمية (الأولوية)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    priorities.forEach { prio ->
                        val isSelected = taskPrio == prio
                        val prioColor = getPriorityColor(prio)
                        Button(
                            onClick = { taskPrio = prio },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) prioColor else prioColor.copy(alpha = 0.1f),
                                contentColor = if (isSelected) Color.White else prioColor
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("dialog_priority_${prio}"),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(prio, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Simple Quick Dates
                Text(
                    text = "موعد الاستحقاق (التاريخ)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                val cal = Calendar.getInstance()
                val todayMs = cal.timeInMillis
                cal.add(Calendar.DAY_OF_YEAR, 1)
                val tomorrowMs = cal.timeInMillis
                cal.add(Calendar.DAY_OF_YEAR, 6)
                val nextWeekMs = cal.timeInMillis

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "اليوم" to todayMs,
                        "غداً" to tomorrowMs,
                        "الأسبوع المقبل" to nextWeekMs
                    ).forEach { (label, time) ->
                        val isDateSelected = isSameDay(taskDate, time)
                        InputChip(
                            selected = isDateSelected,
                            onClick = { taskDate = time },
                            label = { Text(label, fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.CalendarMonth,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dialog_date_${label}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Form Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Cancel
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_cancel_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إلغاء")
                    }

                    // Save
                    Button(
                        onClick = {
                            if (taskTitle.trim().isEmpty()) {
                                isTitleError = true
                            } else {
                                onSubmit(taskTitle.trim(), taskDesc.trim(), taskCat, taskPrio, taskDate)
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("dialog_submit_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("حفظ وتأكيد", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Helper methods to resolve icons and priorities
fun getCategoryIcon(category: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when (category) {
        "عمل" -> Icons.Default.Work
        "شخصي" -> Icons.Default.Person
        "دراسة" -> Icons.Default.School
        "صحة" -> Icons.Default.Favorite
        "أخرى" -> Icons.Default.Folder
        else -> Icons.Default.List
    }
}

fun getPriorityColor(priority: String): Color {
    return when (priority) {
        "عاجل جداً" -> PriorityHigh
        "متوسط" -> PriorityMedium
        else -> PriorityLow
    }
}

fun isSameDay(millis1: Long, millis2: Long): Boolean {
    val cal1 = Calendar.getInstance().apply { timeInMillis = millis1 }
    val cal2 = Calendar.getInstance().apply { timeInMillis = millis2 }
    return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
           cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
}
