package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = OceanTealDark,
    secondary = MintGreenDark,
    tertiary = SunsetGoldDark,
    background = SageDarkBackground,
    surface = CardDarkBg,
    onPrimary = SageDarkBackground,
    onBackground = SageLightBackground,
    onSurface = SageLightBackground
  )

private val LightColorScheme =
  lightColorScheme(
    primary = OceanTeal,
    secondary = MintGreen,
    tertiary = SunsetGold,
    background = SageLightBackground,
    surface = CardLightBg,
    onPrimary = CardLightBg,
    onBackground = SageDarkBackground,
    onSurface = SageDarkBackground
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Custom theme by default, set to true if dynamic local coloring needed
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
