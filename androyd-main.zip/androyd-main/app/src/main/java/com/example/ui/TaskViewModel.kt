package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.TaskEntity
import com.example.data.TaskRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface TaskUiState {
    object Loading : TaskUiState
    data class Success(
        val tasks: List<TaskEntity>,
        val completionRate: Float,
        val completedCount: Int,
        val totalCount: Int
    ) : TaskUiState
}

enum class SortOrder {
    DATE_DESC, DATE_ASC, PRIORITY_HIGH_FIRST, NAME_ASC
}

class TaskViewModel(private val repository: TaskRepository) : ViewModel() {
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("الكل")
    val selectedPriority = MutableStateFlow("الكل")
    val selectedSort = MutableStateFlow(SortOrder.DATE_DESC)

    private var recentlyDeletedTask: TaskEntity? = null

    val uiState: StateFlow<TaskUiState> = combine(
        repository.allTasks,
        searchQuery,
        selectedCategory,
        selectedPriority,
        selectedSort
    ) { allTasks, query, category, priority, sortOrder ->
        var filtered = allTasks.filter { task ->
            val matchesQuery = task.title.contains(query, ignoreCase = true) || 
                               task.description.contains(query, ignoreCase = true)
            val matchesCategory = category == "الكل" || task.category == category
            val matchesPriority = priority == "الكل" || task.priority == priority
            matchesQuery && matchesCategory && matchesPriority
        }

        filtered = when (sortOrder) {
            SortOrder.DATE_DESC -> filtered.sortedByDescending { it.dueDate }
            SortOrder.DATE_ASC -> filtered.sortedBy { it.dueDate }
            SortOrder.NAME_ASC -> filtered.sortedBy { it.title }
            SortOrder.PRIORITY_HIGH_FIRST -> filtered.sortedByDescending { 
                when (it.priority) {
                    "عاجل جداً" -> 3
                    "متوسط" -> 2
                    else -> 1
                }
            }
        }
        
        val completedCount = allTasks.count { it.isCompleted }
        val totalCount = allTasks.size
        val completionRate = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f

        TaskUiState.Success(
            tasks = filtered,
            completionRate = completionRate,
            completedCount = completedCount,
            totalCount = totalCount
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TaskUiState.Loading
    )

    fun addTask(title: String, description: String, category: String, priority: String, dueDate: Long) {
        viewModelScope.launch {
            repository.insert(
                TaskEntity(
                    title = title,
                    description = description,
                    category = category,
                    priority = priority,
                    dueDate = dueDate,
                    isCompleted = false
                )
            )
        }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.update(task)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            recentlyDeletedTask = task
            repository.delete(task)
        }
    }

    fun undoDelete() {
        recentlyDeletedTask?.let { task ->
            viewModelScope.launch {
                repository.insert(task)
                recentlyDeletedTask = null
            }
        }
    }

    fun toggleTask(id: Int, isCompleted: Boolean) {
        viewModelScope.launch {
            repository.toggleComplete(id, isCompleted)
        }
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun selectCategory(category: String) {
        selectedCategory.value = category
    }

    fun selectPriority(priority: String) {
        selectedPriority.value = priority
    }
    
    fun selectSort(sortOrder: SortOrder) {
        selectedSort.value = sortOrder
    }
}

class TaskViewModelFactory(private val repository: TaskRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TaskViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class Exception")
    }
}
